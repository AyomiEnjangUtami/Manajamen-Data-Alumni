Langkah-Langkah Membuat database di xampp:

-- 1. Buat Database
CREATE DATABASE db_alumni;

-- 2. Gunakan Database tersebut
USE db_alumni;

-- Membuat Tabel Alumni
CREATE TABLE alumni (
  id_alumni INT NOT NULL,
  nama VARCHAR(50) NOT NULL,
  angkatan INT NOT NULL,
  jurusan VARCHAR(50) NOT NULL
);

-- Membuat Tabel Users
CREATE TABLE users (
  user_id INT NOT NULL,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(50) NOT NULL,
  role VARCHAR(50) NOT NULL
);

-- Mengatur ID Alumni sebagai Primary Key
ALTER TABLE alumni ADD PRIMARY KEY (id_alumni);
ALTER TABLE alumni MODIFY id_alumni INT NOT NULL AUTO_INCREMENT;

-- Mengatur User ID sebagai Primary Key
ALTER TABLE users ADD PRIMARY KEY (user_id);
ALTER TABLE users MODIFY user_id INT NOT NULL AUTO_INCREMENT;

-- Mengisi data ke tabel Alumni
INSERT INTO alumni (nama, angkatan, jurusan) VALUES
('Bintang', 2025, 'Rekayasa Perangkat Lunak'),
('Raka Jawa', 2026, 'Rekayasa Perangkat Lunak'),
('Azni Lampung', 2026, 'Rekayasa Perangkat Lunak');

-- Mengisi data ke tabel Users
INSERT INTO users (username, password, role) VALUES
('user', 'user', 'user'),
('admin', 'admin', 'admin'),
('superadmin', 'superadmin', 'superadmin');